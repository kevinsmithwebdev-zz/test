import 'raf/polyfill';

import configure from 'enzyme-adapter-react-helper';

configure();
