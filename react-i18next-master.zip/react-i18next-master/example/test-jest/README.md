### Intro

 `./__mocks__` contains the react-i18next mock (mocks translate and Trans; mock other components as needed!!!)

 `./src/setupTests.js` sets adapter for using enzyme

 `./src/App.test.js` basic test from create-react-app
 `./src/MyComponent.test.js` test using enzyme
