import React from 'react';


const SayWelcome = ({ t }) => (
  <div>
    {t('Welcome to React')}
  </div>
);

export default SayWelcome;
