# Getting started

You find the example for next.js and react-i18next here:

[https://github.com/zeit/next.js/tree/canary/examples/with-react-i18next](https://github.com/zeit/next.js/tree/canary/examples/with-react-i18next)

*Using one place for the example makes it easier so we do not have to sync them on every change.*

Beside that there is also a sample to show the usage with **locize** here:

[https://github.com/i18next/react-i18next/tree/master/example/nextjs-locize](https://github.com/i18next/react-i18next/tree/master/example/nextjs-locize)

If you like to cover the full localization process beside instrumenting your code for i18n.
