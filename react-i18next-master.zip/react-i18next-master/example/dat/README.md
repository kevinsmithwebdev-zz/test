This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

## using with Beaker Browser
[hashbase](https://hashbase.io/locize/react-i18next)

## start locally

```bash
# npm start
```
