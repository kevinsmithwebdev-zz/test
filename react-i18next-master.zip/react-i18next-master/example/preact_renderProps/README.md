This project was bootstrapped with [Create Preact App](https://github.com/just-boris/create-preact-app).


## start

```bash
# npm start
```

open `http://localhost:3000` to open your application.
