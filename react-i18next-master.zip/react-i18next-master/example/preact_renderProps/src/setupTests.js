//https://github.com/developit/preact/issues/444
global.SVGElement = global.Element;